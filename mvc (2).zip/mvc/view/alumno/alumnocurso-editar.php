<h1 class="page-header">
    <?php echo $almcur->id != null ? $almcur->Curso_id : 'Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><a href="index.php?c=AlumnoCurso">Matrículas</a></li>
  <li class="active"><?php echo $almcur->id != null ? $almcur->Curso_id : 'Nuevo Registro'; ?></li>
</ol>

<form id="frm-alumnocurso" action="?c=AlumnoCurso&a=Guardar" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $almcur->id; ?>" />
    
    <div class="form-group">
        <label>Curso_id</label>
        <input type="text" name="Curso_id" value="<?php echo $almcur->Curso_id; ?>" class="form-control" placeholder="Ingrese el ID de Curso" data-validacion-tipo="requerido|min:1" />
    </div>
    
    <div class="form-group">
        <label>AlumnoCurso_id</label>
        <input type="text" name="AlumnoCurso_id" value="<?php echo $almcur->AlumnoCurso_id; ?>" class="form-control" placeholder="Ingrese el ID de Alumno" data-validacion-tipo="requerido|min:1" />
    </div>
    

    
    <hr />
    
    <div class="text-right">
        <button class="btn btn-success">Guardar</button>
    </div>
</form>

<script>
    $(document).ready(function(){
        $("#frm-alumnocurso").submit(function(){
            return $(this).validate();
        });
    })
</script>