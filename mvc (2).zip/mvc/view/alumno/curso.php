

<div class="well well-sm text-left">
    <a class="btn btn-primary" href="index.php">Alumnos</a>
    <a class="btn btn-primary" href="index2.php">Curso</a>
    <a class="btn btn-primary" href="index3.php">Matricula</a>
</div>


<h1 class="page-header">Cursos</h1>


<div class="well well-sm text-right">
    <a class="btn btn-primary" href="?c=Curso&a=Crud">Nuevo Curso</a>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th style="width:500px;">ID</th>
            <th style="width:480px;">Nombre</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach($this->model->Listar() as $r): ?>
        <tr>
            <td><?php echo $r->id; ?></td>
            <td><?php echo $r->Nombre; ?></td>
            <td></td>
                 
            <td>
                <a href="?c=Curso&a=Crud&id=<?php echo $r->id; ?>">Editar</a>
            </td>
            <td>
                <a onclick="javascript:return confirm('¿Seguro de eliminar este registro?');" href="?c=Curso&a=Eliminar&id=<?php echo $r->id; ?>">Eliminar</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table> 
