<?php
require_once 'model/alumnocurso.php';

class AlumnoCursoController{
    
    private $model;
    
    public function __CONSTRUCT(){
        $this->model = new AlumnoCurso();
    }
    
    public function Index(){
        require_once 'view/header.php';
        require_once 'view/alumno/alumnocurso.php';
        require_once 'view/footer.php';
    }
    
    public function Crud(){
        $almcur = new AlumnoCurso();
        
        if(isset($_REQUEST['id'])){
            $almcur = $this->model->Obtener($_REQUEST['id']);
        }
        
        require_once 'view/header.php';
        require_once 'view/alumno/alumnocurso-editar.php';
        require_once 'view/footer.php';
    }
    
    public function Guardar(){
        $almcur = new AlumnoCurso();
        
        $almcur->id = $_REQUEST['id'];
        $almcur->Curso_id = $_REQUEST['Curso_id'];
        $almcur->Alumno_id = $_REQUEST['Alumno_id'];


        $almcur->id > 0 
            ? $this->model->Actualizar($almcur)
            : $this->model->Registrar($almcur);
        
        header('Location: index3.php');
    }
    
    public function Eliminar(){
        $this->model->Eliminar($_REQUEST['id']);
        header('Location: index3.php');
    }
}